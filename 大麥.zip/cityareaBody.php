<?php
/** 
 * eip> basic > 城市地區 list
 * 
 * @author alex 
 * @since 2020/12/08
 */
//# 樣版
$html = _comGetInstance('esmarty');
$html->set_dir('/mgr_html/eip/address/');

$mgrCtrl = _comGetInstance('mgrCtrl', '', array($sql));

$ww['isSearch'] = true;
$page = (int)$_GET['page'];
if($page <= 0) { 
    $page = 1;
}
$pagesize = 100;

## handle search condition
foreach($_GET as $k=> $v) {
    $_GET[$k] = trim($v); 
}
//取得orderBy 
$orderBy = _comGetOrderBy($_GET['disp']);
$_GET['isAll'] = 't';
//設定fromWhere 
$cmd = $mgrCtrl->callCtrl('eip_address_cityarea', 'getWhere', $_GET); 
if(strlen($orderBy)) {
    $cmd['orderBy'] = $orderBy;
}
$data = $sql->dlimit($cmd, $page, '', $pagesize);
$arr = &$data['data'];

if($arr[0] > 0) {
    $ww['isData'] = true;
    
    for($i=1; $i<=$arr[0]; $i++) {
        $v = &$arr[$i];
        $arr[$i]['index'] = $i-1;
    }
    
    $html->assign('p', $arr, true);
    
    //page
    $page = _comShowPage($data['total_count'], $page, $pagesize);
    $html->assign($page);
}

$html->assign($ww);
$html->display('cityareaBody.htm');
?>