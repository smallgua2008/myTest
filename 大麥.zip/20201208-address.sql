--author: alex 
--since: 2020/12/08


CREATE SEQUENCE "cityarea_area_id__seq" START 1 INCREMENT 1 MAXVALUE 2147483647 MINVALUE 1 CACHE 1;
CREATE TABLE cityarea (
  area_id int4 DEFAULT NEXTVAL('cityarea_area_id__seq'::TEXT) NOT NULL,
  user_id int4 not null, 
  city varchar(50),
  area varchar(50),
  date_create timestamp(0) without time zone default now(),
  primary key(area_id) 
); 

CREATE SEQUENCE "address_address_id__seq" START 1 INCREMENT 1 MAXVALUE 2147483647 MINVALUE 1 CACHE 1;
CREATE TABLE address(
  address_id int DEFAULT NEXTVAL('address_address_id__seq'::TEXT) NOT NULL,
  area_id int4 not null, 
  name varchar(255) not null, 
  abc varchar(50),
  primary key(address_id, area_id) 
); 