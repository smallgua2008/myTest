<?php
/** 
 * eip> basic > 城市地區 處理
 * 
 * @author alex 
 * @since 2020/12/08
 */
define('_callModule', 'eip_address_cityarea'); 

include 'chk.php'; 
 
?>