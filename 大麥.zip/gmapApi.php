<?php
/** 
 * eip> address > gmap api
 * 
 * @author alex 
 * @since 2020/12/08
 */

if($_GET['func'] == 'getAddr') {
    
    $mgrCtrl = _comGetInstance('mgrCtrl', '', array($sql));
    if(!strlen($_GET['addr'])) {
        _comOutputJSON(false, '地址為必填寫');
        exit;
    }
    
    $in = array(
        'addr'=> $_GET['addr'],
    ); 
    $rtn = $mgrCtrl->callCtrl('eip_address_cityarea', 'getMapAddr', $in); 
    _comOutputJSON(true, '', $rtn);
    
    exit;
}    

 
//# 樣版
$html = _comGetInstance('esmarty');
$html->set_dir('/mgr_html/eip/address/');

$html->assign($ww);
$html->display('gmapApi.htm');
?>