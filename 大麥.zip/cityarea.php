<?php
/** 
 * eip> basic > 城市地區
 * 
 * @author alex 
 * @since 2020/12/08
 */
//# 樣版
$html = _comGetInstance('esmarty');
$html->set_dir('/mgr_html/eip/address/');

$html->assign($ww);
$html->display('cityarea.htm');
?>